<?php include('functions.php'); 
       
       if($_SERVER['REQUEST_METHOD'] == "POST"){
           $EMAIL = $_POST['EMAIL'];
           $PASSWORD = $_POST['PASSWORD'];
          doLogin($EMAIL,$PASSWORD);
       }
     
  
  
?>
<html>
  <head>
    <title>Customer Login - Dell</title>
    <meta charset="utf-8">
    <meta content="ie=edge" http-equiv="x-ua-compatible">
    <meta content="template language" name="keywords">
    <meta content="Tamerlan Soziev" name="author">
    <meta content="Admin dashboard html template" name="description">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <link href="./dist/favicon.png" rel="shortcut icon">
    <link href="./dist/apple-touch-icon.png" rel="apple-touch-icon">
    <link href="./dist/https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet" type="text/css">
    <link href="./dist/bower_components/select2/dist/css/select2.min.css" rel="stylesheet">
    <link href="./dist/bower_components/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <link href="./dist/bower_components/dropzone/dist/dropzone.css" rel="stylesheet">
    <link href="./dist/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="./dist/bower_components/fullcalendar/dist/fullcalendar.min.css" rel="stylesheet">
    <link href="./dist/bower_components/perfect-scrollbar/css/perfect-scrollbar.min.css" rel="stylesheet">
    <link href="./dist/bower_components/slick-carousel/slick/slick.css" rel="stylesheet">
    <link href="./dist/css/main.css?version=4.4.0" rel="stylesheet">
    <style>
        
        .logged-user-w{
            display:none;
        }
        
        .main-menu{
            display:none;
        }
        
        
    </style>
  </head>
  <body class="auth-wrapper">
    <div class="all-wrapper menu-side with-pattern">
      <div class="auth-box-w">
        <div class="logo-w">
          <a href="./dist/index.html"><img alt="" src="./dist/img/logo-big.png"></a>
        </div>
        <?php showAlerts(); ?>
        <h4 class="auth-header">
          Customer Login
        </h4>
        <form method="POST">
          <div class="form-group">
            <label for="">Email</label><input name="EMAIL" class="form-control" placeholder="Enter your email" type="email">
            <div class="pre-icon os-icon os-icon-user-male-circle"></div>
          </div>
          <div class="form-group">
            <label for="">Password</label><input name="PASSWORD" class="form-control" placeholder="Enter your password" type="password">
            <div class="pre-icon os-icon os-icon-fingerprint"></div>
          </div>
          <div class="buttons-w">
            <button class="btn btn-primary">Log me in</button>
            <div class="form-check-inline">
              <label class="form-check-label"><input class="form-check-input" type="checkbox">Remember Me</label>
            </div>
          </div>
        </form>
      </div>
    </div>
  </body>
</html>
