<?php 
include('../functions.php');

$MESSAGE = strtoupper($_GET['userMessage']);
$WORDS = explode(" ",$MESSAGE);


if(isGreetings() && !isset($_SESSION['ORDERHELP'])){
    endoutput("Hello there! Do you need help with an order?");
} else{
    
    if(!isset($_SESSION['ORDERHELP'])){
         $_SESSION['ORDERHELP'] =  userConfirmation();
         echo("Thank you for stating. ");
         
         if($_SESSION['ORDERHELP']){
          endoutput("Please state your Order Number");
         }
         else {
          endoutput("If you don't need help with an Order. You may refer to FAQ for additional problems.");
         }
         
         
    } else{
        
        if($_SESSION['ORDERHELP']){
           if(!isset($_SESSION['ORDERNO'])){
               $ORDERNO = containsOrderNo();
                 if($ORDERNO){
                      $QUERY = "SELECT * FROM ORDERS WHERE ORDER_NO = '$ORDERNO'";
                      $RESULT = Query($QUERY);
                      if($RESULT && mysqli_num_rows($RESULT) == 1){
                         $_SESSION['ORDERNO'] = $ORDERNO;
                        endoutput("Thank you for letting me your order number. Please let me know the issue.");
                      } else {
                          endoutput("Invalid Order Number. Please enter a valid order number! ");
                      }    
                 } else{
                     endoutput("Can I have an order number please?");
                 }
            } else{
                $ORDERNO = $_SESSION['ORDERNO'];
                $QUERY = "SELECT DEPARTMENT,STATUS_DETAIL FROM `ORDERS` INNER JOIN ORDERSTATUS ON ORDERSTATUS.STATUSID = ORDERS.STATUSID WHERE ORDER_NO = '$ORDERNO'";
                $RESULT = Query($QUERY);
                $ROW = mysqli_fetch_assoc($RESULT);
                endoutput($ROW['DEPARTMENT']." Reply: ".$ROW['STATUS_DETAIL']);
            }
        } else{
            endoutput("You don't need help with order. Please go check FAQ for additional problems");
            
            
        }
        
        
    }
    
    
}


function isGreetings(){
    $toCheck = array("HELLO","HEY","HI","SUP","HEYY","HEYYY");
    if(commonWords($toCheck))
        return true;
    return false;
} 

function containsOrderNo(){
    global $WORDS;
   foreach($WORDS as $singleWord){
       if(strlen($singleWord)==9){
         $orderNo = $singleWord;
         $orderNoArr = str_split($orderNo);
         if($orderNoArr[4]=='-')
          return $orderNo;
       } 
   }
   return false;
}

function userConfirmation(){
    $toCheck = array("SURE","YES","YEAH");
    if(commonWords($toCheck))
        return true;
    return false;    
}



function commonWords($toCheck){
 global $WORDS;
 
 foreach($toCheck as $singleWord){
     array_push($toCheck,$singleWord.",",$singleWord.".",$singleWord."!");
 }
 $c = array_intersect($WORDS, $toCheck);
 if (count($c) > 0) 
    return true;
 return false;    
}


