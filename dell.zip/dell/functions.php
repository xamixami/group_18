<?php
session_start();

//DATABASE CREDENTIALS
$con = mysqli_connect("localhost","qyzxiwpm_dell","qyzxiwpm_dell","qyzxiwpm_dell");
if (mysqli_connect_errno()){
  echo "Failed to connect to MySQL: " . mysqli_connect_error(); exit();
} 

//SANITIZE ALL USER INPUTS
foreach($_GET as $k=>$v)  {$_GET[$k] = sanitize($v); }
foreach($_POST as $k=>$v) {$_POST[$k] = sanitize($v);}


function sanitize($string){
    global $con;
    $string = stripslashes($string); // removes backslashes
	return mysqli_real_escape_string($con,$string);
}

//Initialize Errors Array
$errors = array();

//Core Functions
function redirect($LOCATION){
    header('Location: '.$LOCATION); exit();
}

function Query($QUERY){
    global $con;
    return mysqli_query($con,$QUERY);
}

function Auth(){
    global $con;
    if(empty(User()))
        redirect('login.php');
    $currentTime=time();
    $EMAIL = User();
}


function endoutput($var){
    echo $var; exit();
}

function dump($var){
    echo "<pre>";
    var_dump($var);
    echo "</pre>";
}

function User(){
    if(isset($_SESSION['email']))
     return $_SESSION['email'];
    return false; 
}

function showAlerts(){
    global $errors;
    foreach($errors as $error){
        echo $error;
    }
}

function doLogin($EMAIL,$PASSWORD){
        global $errors;
		$QUERY = "SELECT PASSWORD FROM `CUSTOMERS` WHERE EMAIL='$EMAIL'";
		$RESULT = Query($QUERY);
		
		if(mysqli_num_rows($RESULT)===1)
        {  
            $ROW=mysqli_fetch_array($RESULT);
            $PASSWORD_HASH=$ROW[0];
            if(strcmp(md5($PASSWORD), $PASSWORD_HASH)===0){
                $_SESSION['email']=$EMAIL;
               redirect('index.php');
            }
        }
           array_push($errors,'<div class="alert alert-danger" role="alert"><strong>Oh snap! </strong>Invalid Credentials</div>');
}


function isAdmin(){
    $EMAIL  = User();
    $QUERY  = "SELECT RIGHTS FROM USERS WHERE EMAIL = '$EMAIL'";
    $RESULT = Query($QUERY);
    $RIGHTS = mysqli_fetch_assoc($RESULT)["RIGHTS"];
    if($RIGHTS==1)
     return true;
    return false;
}


function Admin(){
    if(!isAdmin())
      redirect('index');
}

function isEmailValid($email) 
{
    if(is_array($email) || is_numeric($email) || is_bool($email) || is_float($email) || is_file($email) || is_dir($email) || is_int($email))
        return false;
    else
    {
        $email=trim(strtolower($email));
        if(filter_var($email, FILTER_VALIDATE_EMAIL)!==false) return $email;
        else
        {
            $pattern = '/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD';
            return (preg_match($pattern, $email) === 1) ? $email : false;
        }
    }
}